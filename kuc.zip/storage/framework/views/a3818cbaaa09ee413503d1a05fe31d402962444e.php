<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-heading"><big>Edit supplier: <strong><big><?php echo e($supplier->name); ?></big></strong></big></div>
            <div class="panel-body">
                <form class="form-horizontal" role="form" method="POST" action="/suppliers/<?php echo e($supplier->id); ?>">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="_method" value="PUT">

                        <div class="form-group">
                            <label class="col-md-4 col-sm-4 control-label">category</label>
                            <div class="col-md-3 col-sm-3">
                               
                            <select id="cat"  name="cat" class="form-control" data-width="100%"><option value="<?php echo e($supplier->cat_id); ?>" selected="<?php echo e($supplier->cat->name); ?>"><?php echo e($supplier->cat->name); ?></option></select>
                        <input type="hidden" id="cat_id" value="<?php echo e($supplier->cat_id); ?>" name="cat_id"/>
                                
                        </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-4 control-label">name</label>
                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="name" value="<?php echo e($supplier->name); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-4 control-label">address</label>
                            <div class="col-md-6">
                                <input id="address" type="text" class="form-control" name="address" value="<?php echo e($supplier->address); ?>">
                            </div>
                        </div>

                         <div class="form-group">
                            <label class="col-md-4 control-label">tel</label>
                            <div class="col-md-2">
                                <input id="tel" type="text" class="form-control" name="tel" value="<?php echo e($supplier->tel); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-4 control-label">email</label>
                            <div class="col-md-3">
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e($supplier->email); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-btn fa-plus"></i> update
                                </button>
                            </div>
                        </div>
                    </form>
                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("script"); ?>

<?php echo $__env->make('layouts.suggest', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script>

    GetSuggestions("cat","name","cats");

     $('#cat').on('select2:select', function (evt) {
         var cat_id=evt.params.data.id;
           $('#cat_id').val(cat_id);
           GetColumnData(cat_id,"symbol","cats","#code");
       
   
    });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>