
<?php if(count($errors)>0): ?>


    <div class="alert alert-danger">
        <ul>
            <?php foreach($errors->all() as $error): ?>
                <li><?php echo e($error); ?></li>
                
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<?php if(session('success')): ?>
    <div class="alert alert-success">
    <?php echo session('success'); ?>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger">
    <?php echo session('error'); ?>

    </div>
<?php endif; ?>

<?php /* <script>
$( document ).ready(function() {
    $(document).trigger("add-alerts", [
                {
                "message":'sucessfully removed',
                "priority": 'success'
                }
                ]);
});

</script> */ ?>