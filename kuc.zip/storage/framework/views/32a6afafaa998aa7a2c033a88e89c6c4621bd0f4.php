<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-heading"><big>EDIT ISSUE</big></div>
            <div class="panel-body">
                <form class="form-horizontal" role="form" method="POST" action="/issues/<?php echo e($issue->id); ?>">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="_method" value="PUT">

                        <div class="form-group">
                            <label class="col-md-4 control-label">officer</label>
                            <div class="col-md-3">
                               <select id="name"  class="form-control" >
                                    <option value="<?php echo e($issue->officer_id); ?>" selected=" <?php echo e($issue->officer->name); ?>">
                                        <?php echo e($issue->officer->name); ?>

                                    </option>
                                </select>
                            <input type="hidden" id="officer_id" name="officer_id" value="<?php echo e($issue->officer_id); ?>" />
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-4 control-label">date of issue</label>
                            <div class="col-md-3">
                                <input id="datepicker" type="text" class="datepicker form-control" name="issue_date" value="<?php echo e($issue->issue_date); ?>">
                            </div>
                        </div>

                         <div class="form-group">
                            <label class="col-md-4 control-label">description</label>
                            <div class="col-md-4">
                               <textarea name="description" class="form-control"><?php echo e($issue->description); ?></textarea>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-btn fa-plus"></i> update
                                </button>
                            </div>
                        </div>
                    </form>
                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('script'); ?>
 <?php /* auto suggest */ ?>
    <?php echo $__env->make('layouts.suggest', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;

    <script>
       GetSuggestions("name","name","officers");

        $('#name').on('select2:select', function (evt) {
            console.log(evt.params.data.id);
            $('#officer_id').val(evt.params.data.id);
        });
    </script>
    <?php /* end of autosuggest */ ?>
<?php $__env->stopSection(); ?> 





<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>