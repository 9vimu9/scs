<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-heading">
                <big>ISSUES</big>
                <a href="/issues/create" class="pull-right btn btn-primary btn-sm">add issue</a>
            </div>
                <div class="panel-body">
                    <?php if(count($issues)>0): ?>
                     <table class="table table-striped table-hover" style="width: 92%" >
                    <thead>
                        <tr>
                            <th style="width: 10%">issue</th>
                            <th style="width: 15%">officer</th>
                            <th style="width: 12%">date</th>
                            <th style="width: 30%">description</th>
                            <th style="width: 15%">created</th>
                            <th style="width: 15%">last updated</th>
                            <th style="width: 10%"></th>
                           
                        </tr>
                    </thead>
                        <?php foreach($issues as $issue): ?>
                            <tr>
                                <td> <big><?php echo e($issue->id); ?></big></td>
                               <td> <?php echo e($issue->officer->name); ?></td>
                                <td> <?php echo e($issue->issue_date); ?></td>
                                 <td> <?php echo e($issue->description); ?></td>
                                  <td> <?php echo e($issue->created_at->format('Y-m-d_H:m')); ?></td>
                                   <td> <?php echo e($issue->updated_at->format('Y-m-d_H:m')); ?></td>
                                 

                                <td> <a href="/issueitems/<?php echo e($issue->id); ?>" class="btn btn-warning btn-xs">more</a> </td>
                            </tr>
                                
                    <?php endforeach; ?>
                    </table>
                        <?php echo e($issues->links()); ?>

                    <?php else: ?>
                    no issues<br>click add issue button
                    
                    <?php endif; ?>
                </div>
            
        </div>
      
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>