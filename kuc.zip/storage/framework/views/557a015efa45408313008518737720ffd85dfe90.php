<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-heading">
                <big>ITEM REQUEST REPORTS</big>
                <a href="/stores/current" class="pull-right btn btn-primary btn-sm">new report</a>
            </div>
                <div class="panel-body">
                    <?php if(count($reportrequests)>0): ?>
                      <table id="table" class="table  table-striped" width="75%">
                <thead>
               <tr>
                            <th width="10%">no</th>
                            <th width="20%">date</th>
                            <th width="40%">type</th>
                            <th width="16%"></th>
                           
                           
                        </tr>
                </thead>
                <tbody>
                <?php foreach($reportrequests as $reportrequest): ?>
                            <tr bgcolor=<?php echo e($reportrequest->type==1 ? "#B2D732" : "#fff"); ?>>
                           
                                <td><?php echo e($reportrequest->id); ?></td>

                                <td><?php echo e($reportrequest->created_at->format('Y-m-d_H:m')); ?></td>

                               
                                <?php if($reportrequest->type==1): ?>
                                 <td >
                                   <span class="badge">monthly</span>  request report for <strong><big><?php echo e($reportrequest->created_at->format('M , Y')); ?></big></strong>
                                <?php else: ?>
                                    <td bgcolor="">
                                      <span class="badge">urgent</span> request report on <?php echo e($reportrequest->created_at->format('Y-m-d H:m')); ?>

                                <?php endif; ?>
                                </td>
                                
                                   <td>

                                    <form action="/destroy_request_report/<?php echo e($reportrequest->id); ?>" class="form-group" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <a href="/requestselected/<?php echo e($reportrequest->id); ?>" class="btn btn-warning btn-xs">more</a>
                                        <input type="submit" name="delete" value="delete" class="btn btn-danger btn-xs">
                                        <input type="hidden" name="_method" value="DELETE">
                                       
                                    </form>
                                </td>
                            </tr>
                           
                               
                              
                            
                    <?php endforeach; ?>
                </tbody>
                
              </table>
                       
                    <?php else: ?>
                    no officers<br>click add officer button
                    
                    <?php endif; ?>
                </div>
            
        </div>
      
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
  $(function () {
   
    $('#table').DataTable({
        'paging'      : false,
        'lengthChange': false,
        'searching'   : true,
        'ordering'    : true,
        'info'        : false,
        'autoWidth'   : true,
        'order': [[ 0, "desc" ]],
    })
  })
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>