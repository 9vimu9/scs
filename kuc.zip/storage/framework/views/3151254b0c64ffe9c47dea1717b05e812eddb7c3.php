<?php $__env->startSection('head'); ?>


 <link rel="stylesheet" href="<?php echo e(asset('css/checkbox.css')); ?>" >
 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container" >
<form  method="GET" action="/to_request_report">
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-heading">
                <div class="btn-toolbar">
                    <big>current situation</big>
               
              
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="selected_ids" id="selected_ids" value="0">
                    
                    <input type="submit" id="to_this_month_button" class="pull-right btn btn-primary btn-sm" value="this month report" name="btn_this_month">
                    <input type="submit" id="to_quick_button" class="pull-right btn btn-warning btn-sm" value="quick item request"  name="btn_quick"> 
                   
                </form>

                </div>
            </div>
            <div class="panel-body">
            <?php if(count($items)>0): ?>
                <table id="current" class="table table-hover table-striped"  width="100%">
                    <thead>
                        <tr>
                            <th width="25%">name</th>
                            <th width="5%">now</th>
                            <th width="10%">reorder</th>
                            <th width="15%">category</th>
                            <th width="10%">code</th>
                            <th width="10%">location</th>
                           
                            <th width="8%">max</th>
                            
                            <th width="8%">min</th>
                            <th width="20%">add
                            
                                        <div class="material-switch pull-right">
                                            <input id="mainAdd" name="mainAdd" type="checkbox" />
                                            <label for="mainAdd" class="label-default"></label>
                                        </div>
                                   


                            </th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php foreach($items as $item): ?>
                            <?php if(($item->reorder-$item->current)>=0): ?>
                            
                                <tr>
                                    <td> <a href="/items/<?php echo e($item->id); ?>"><?php echo e($item->name); ?></a></td>
                                    <td><?php echo e($item->current); ?></td>
                                    <td><?php echo e($item->reorder); ?></td>
                                    <td><?php echo e($item->cat->name); ?></td>
                                
                                    <td><?php echo e($item->code); ?></td>
                                    <td><?php echo e($item->location); ?></td>
                                    
                                    <td><?php echo e($item->max); ?></td>
                                
                                    <td><?php echo e($item->min); ?></td>
                                
                                    <td>

                                        <div class="material-switch ">
                                            <input id="toreport_<?php echo e($item->id); ?>" name="toreport" class="to_report" type="checkbox" />
                                            <label for="toreport_<?php echo e($item->id); ?>" class="label-danger"></label>
                                        </div>
                                    </td>
                                </tr>
                                
                                    
                                    
                            <?php endif; ?>        
                        <?php endforeach; ?>   
              
                    </tbody>
                
                </table>
            <?php else: ?>
                no officers<br>click add officer button
                    
            <?php endif; ?>

            </div>
            
        </div>
      
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("script"); ?>
<script> 
$(document).ready(function() {

    $("#to_this_month_button, #to_quick_button").click(function() {
        var selected_ids=[];
        $('.to_report').each(function(){
            if(this.checked){
                var item_id=$(this).attr('id').split("_")[1];
                selected_ids.push(item_id);


            }
            
        })

        $("#selected_ids").val(selected_ids);
    });




     $('#mainAdd').change(function(){
          $('.to_report').prop("checked", this.checked);
        
     });

    $('#current').DataTable( {
        "columnDefs": [{"targets": 8,"orderable": false}],
        "order": [[ 1, "asc" ]],
         "createdRow": function ( row, data, index ) {
             var val=255;
             var diffrence=data[2]-data[1];
             if(diffrence>0){
                val=265-(diffrence/data[6])*255-50;
                val=parseInt(val);
             
             }
             console.log(val);
           
            
                $('td', row).eq(1).css({'font-size':' 120%',"font-weight": "bold", "background-color": "rgb(200, "+val+",100 )"});
            
        }
    } );
//window.onload = function() { window.print(); }
});

</script>

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>