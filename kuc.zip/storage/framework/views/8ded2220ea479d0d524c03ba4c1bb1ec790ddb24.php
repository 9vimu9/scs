<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-heading">
                <big>LOAN ACCOUNT ISSUE</big>
                <a href="/loanissues/create" class="pull-right btn btn-primary btn-sm">add loan account</a>
            </div>
                <div class="panel-body">
                    <?php if(count($loanissues)>0): ?>
                     <table class="table table-striped table-hover" style="width: 90%" >
                    <thead>
                        <tr>
                            <th style="width: 10%">issue</th>
                            <th style="width: 15%">officer</th>
                            <th style="width: 12%">date</th>
                            <th style="width: 30%">description</th>
                            <th style="width: 15%">created</th>
                            <th style="width: 15%">last updated</th>
                            <th style="width: 10%"></th>
                           
                        </tr>
                    </thead>
                        <?php foreach($loanissues as $loanissue): ?>
                            <tr>
                                <td> <big><?php echo e($loanissue->id); ?></big></td>
                               <td> <?php echo e($loanissue->officer->name); ?></td>
                                <td> <?php echo e($loanissue->issue_date); ?></td>
                                 <td> <?php echo e($loanissue->description); ?></td>
                                  <td> <?php echo e($loanissue->created_at->format('Y-m-d_H:m')); ?></td>
                                   <td> <?php echo e($loanissue->updated_at->format('Y-m-d_H:m')); ?></td>
                                 

                                <td> <a href="/itemloanissues/<?php echo e($loanissue->id); ?>" class="btn btn-warning btn-xs">more</a> </td>
                            </tr>
                                
                    <?php endforeach; ?>
                    </table>
                        <?php echo e($loanissues->links()); ?>

                    <?php else: ?>
                    no loan accounts<br>click add loan issue button
                    
                    <?php endif; ?>
                </div>
            
        </div>
      
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>