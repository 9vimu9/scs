කැනස /AC/ ගබඩා /...... 
කැස්බෑව නගර සභාව ,
2016/11/01
ලේකම්,කැස්බෑව නගර සභාව, 
2016 නොවෙම්බර් මාසය සදහා ගබඩාවට භාණ්ඩ ලබා ගැනීම 
2016 නොවැම්බර මාසය සදහා පහත සදහන් භාණ්ඩ ලබා ගැනීමට අවශ්‍යව ඇත. ඒ සදහා අනුමැතිය ලබා දෙන මෙන් කාරුණිකව ඉල්ලා සිටිමි. 
අනු අංකය ඉල්ලුම් කරන භාණ්ඩ ඉල්ලුම් කරන ප්‍රමාණය දිනට ශේෂය 
අත්සන 
ගබඩා භාරකරු 
දිනය 
සැපයුම් නිලධාරි, ඉහත භාණ්ඩ ලබා දීමට අවශ්‍ය කටයුතු කරන්න 
ලේකම් කැස්බෑව නගර සභාව 

<!DOCTYPE html>
<html>

<head>
<style>
        body {
            font-family: 'Lato';
        }

        .fa-btn {
            margin-right: 6px;
        }

        .table {
            border-radius: 5px;
            
            margin: 0px auto;
            float: none;
        }
    </style>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>dfdsgd</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css" integrity="sha384-XdYbMnZ/QjLh6iI4ogqCTaIjrFk87ip+ekIjefZch0Y+PvJ8CDYtEs1ipDmPorQ+" crossorigin="anonymous">
    <!-- Styles -->
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous"> <?php /* <link href="<?php echo e(elixir('css/app.css')); ?>" rel="stylesheet"> */ ?>
    <?php /* datatables */ ?>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.15/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.1.1/css/responsive.bootstrap.min.css">



    <!-- Google Font -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body >
<?php /* onload="window.print();" */ ?>
    <div class="wrapper">
        <div class="row">
            <div class="col-xs-10">
               <p class="pull-right">කැනස /AC/ ගබඩා /......<br> කැස්බෑව නගර සභාව,<br>2016/11/01</p> 
        
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
               <p >ලේකම්,<br>කැස්බෑව නගර සභාව,</p> 
        
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
               <p >2016 නොවෙම්බර් මාසය සදහා ගබඩාවට භාණ්ඩ ලබා ගැනීම</p> 
        
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <p>
                    2016 නොවැම්බර මාසය සදහා පහත සදහන් භාණ්ඩ ලබා ගැනීමට අවශ්‍යව ඇත. ඒ සදහා අනුමැතිය ලබා දෙන මෙන් කාරුණිකව ඉල්ලා සිටිමි. 
                </p> 
        
            </div>
        </div>
        <div class="panel-body">
                   <?php if(count($reportrequest->items_reportrequest)>0): ?>
                    <table id="current" class="table table-hover table-striped"  width="75%">
                        <thead>
                            <tr>
                            <th style="width: 10%">අනු අංකය</th>
                            <th style="width: 25%">ඉල්ලුම් කරන භාණ්ඩ</th>
                            <th style="width: 15%">ඉල්ලුම් කරන ප්‍රමාණය</th>
                            <th style="width: 20%">දිනට ශේෂය</th>
                            </tr>
                        </thead>


                        <tbody>
                            <?php foreach($reportrequest->items as $items_reportrequest): ?>
                             
                                <tr>
                                    <td><?php echo e($items_reportrequest->code); ?></td>
                                    <td><?php echo e($items_reportrequest->name); ?></a></td>
                                    <td><?php echo e($items_reportrequest->pivot->requested_amount); ?></a></td>
                                    
                                    <td><?php echo e($items_reportrequest->pivot->amount_in_store); ?></td>
                                
                                </tr>
                                    
                            <?php endforeach; ?>   
                
                        </tbody>
                    
                    </table>
                <?php else: ?>
                  no item requested
                        
                <?php endif; ?>
                </div>
    </div>

</body>
</html>