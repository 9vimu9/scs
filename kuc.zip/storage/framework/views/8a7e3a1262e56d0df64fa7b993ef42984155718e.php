<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-heading">
                <big>Goods receive notes</big>
                <a href="/receives/create" class="pull-right btn btn-primary btn-sm">add grn</a>
            </div>
                <div class="panel-body">
                <?php echo e(($receives)); ?>

                    <?php if(count($receives)>0): ?>
                     <table class="table table-striped table-hover" style="width: 100%" >
                    <thead>
                        <tr>
                            <th style="width: 8%">grn #</th>
                            <th style="width: 8%">order #</th>
                            <th style="width: 12%">date</th>
                            <th style="width: 10%">quantity</th>
                            <th style="width:10%">rejected</th>
                            <th style="width:10%">accepted</th>
                            <th style="width: 10%">total(Rs)</th>
                            <th style="width: 15%">created</th>
                            <th style="width: 15%">last updated</th>
                            <th style="width: 10%"></th>
                        </tr>
                    </thead>
                        <?php foreach($receives as $receive): ?>
                            <tr>
                                <td> <big><?php echo e($receive->id); ?></big></td>
                                <td> <a href="/itemorders/<?php echo e($receive->order_id); ?>"><?php echo e($receive->order_id); ?></a></td>
                               
                                <td> <?php echo e($receive->date); ?></td>
                               
                                <?php if(count($receive->items)>0): ?>
                                <?php
                                    $amount=0;
                                    $reject_amount=0;
                                    $tot_rs=0;

                                    foreach($receive->items as $item_receive){
                                        $amount+=$item_receive->pivot->amount;
                                        $reject_amount+=$item_receive->pivot->rejected;
                                        
                                        foreach($receive->order->items as $item_order){

                                            if($item_order->pivot->item_id===$item_receive->pivot->item_id){
                                                $tot_rs+=($item_receive->pivot->amount-$item_receive->pivot->rejected)*$item_order->pivot->unit_price;
                                            }
                                        }
                                        
                                      
                                   }
                                ?>
                                    
                                
                                <td> <?php echo e($amount); ?></td>
                                <td><?php echo e($reject_amount); ?></td>
                                <td> <?php echo e($amount-$reject_amount); ?></td>
                                <td><?php echo e($tot_rs); ?></td>
                               
                                
                                <?php else: ?>
                                    <td>0</td>
                                    <td>0</td>
                                     <td>0</td>
                                    <td>0</td>
                                 <?php endif; ?>
                                    <td><?php echo e($receive->created_at->format('Y-m-d_H:m')); ?></td>
                                    <td><?php echo e($receive->updated_at->format('Y-m-d_H:m')); ?></td>
                                <td> <a href="/itemreceives/<?php echo e($receive->id); ?>" class="btn btn-warning btn-xs">more</a> </td>
                            </tr>
                                
                    <?php endforeach; ?>
                    </table>
                        <?php echo e($receives->links()); ?>

                    <?php else: ?>
                    no GRN<br>click add GRN button
                    
                    <?php endif; ?>
                </div>
            
        </div>
      
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>