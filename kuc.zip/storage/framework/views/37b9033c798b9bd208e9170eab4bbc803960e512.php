<?php $__env->startSection('content'); ?>
<div class="container ">
    <div class="row ">
        <div class="panel panel-default ">
            <div class="panel-heading">
                <big><?php echo e($item->name); ?></big>
                &nbsp&nbsp    
                category :<strong class="text-info"><big><?php echo e($item->cat->name); ?></big></strong>
                &nbsp&nbsp    
                item code : <strong class="text-info"><big><?php echo e($item->code); ?></big></strong>
                &nbsp&nbsp    
                location : <strong class="text-info"><big><?php echo e($item->location); ?></big></strong>
                <div class="pull-right">&nbsp&nbsp    
                max level: <strong class="text-info"><big><?php echo e($item->max); ?></big></strong>
                &nbsp&nbsp    
                min level: <strong class="text-info"><big><?php echo e($item->min); ?></big></strong>
                &nbsp&nbsp    
                reorder level: <strong class="text-info"><big><?php echo e($item->reorder); ?></big></strong>
               
            </div>
                
            
            
            <div class="panel-body">
                <?php if(count($logs)>0): ?>
                    <?php
                        $previous_date=0;
                        $balance=0;

                        $link_prhase="";   
                        $title="";
                        $no_col_header="";   
                    ?>
                    <table id="log" class="table  table-hover table-bordered" style="width: 55%" >
                        <thead>
                            <tr>
                                <th>type</th>
                                <th>#no</th>
                                <th>quantity</th>
                                <th>balance</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php foreach($logs as $log): ?>
                                                    
                                <?php if($previous_date!=$log->date): ?>
                            
                                    <?php
                                        $previous_date=$log->date;
                                    ?>
                                    <tr class="bg-info">
                                        <td colspan="4" style="text-align: center"> <?php echo e($log->date); ?></td>
                                        <td style="display: none;"></td>
                                        <td style="display: none;"></td>
                                        <td style="display: none;"></td>
                                    </tr>                            
                                <?php endif; ?>

                                <tr>
                                
                                    <?php
                                        if($log->type=="o"){
                                            $link_prhase="/itemorders/";
                                            $title="ORDERED";
                                            $no_col_header="order #";
                                        
                                        }else if($log->type=="r"){
                                            $link_prhase="/itemreceives/";
                                            $title="RECEIVED";
                                            $no_col_header="GRN #";
                                            $balance+=$log->amount;
                                        
                                        }else if($log->type=="i"){
                                            $link_prhase="/issueitems/";
                                            $title="ISSUED";
                                            $no_col_header="IO #";
                                            $balance-=$log->amount;
                                            
                                        }else if($log->type=="li"){
                                            $link_prhase="/itemloanissues/";
                                            $title="LOAN ACCOUNT ISSUED";
                                            $no_col_header="LIO #";
                                            $balance-=$log->amount;
                                            
                                        
                                        }else if($log->type=="lir"){
                                            $link_prhase="/itemloanissuereturns/";
                                            $title="LOAN ITEM RETURNED";
                                            $no_col_header="LIRO #";
                                            $balance+=$log->amount;
                                            
                                        }
                                    ?>
                                    <td><?php echo e($title); ?></td>
                                    <td><a href="<?php echo e($link_prhase.$log->id); ?>"><?php echo e($no_col_header.$log->id); ?></a></td>
                                    <td><?php echo e($log->amount); ?></td>
                                    <td><?php echo e($balance); ?></td>

                                </tr>
                                        
                            
                            <?php endforeach; ?>
                        </tbody>

                    </table>

                <?php else: ?>
                no history
                
                <?php endif; ?>
            </div>
            
        </div>
      
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
  $(function () {
   
    $('#log').DataTable({
      'paging'      : true,
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : false,
      'info'        : true,
      'autoWidth'   : true
    })
  })
</script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>