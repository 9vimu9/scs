<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-heading">
                <big>ORDERS </big>
                <a href="/orders/create" class="pull-right btn btn-primary btn-sm">add order</a>
            </div>
                <div class="panel-body">
                    <?php if(count($orders)>0): ?>
                     <table class="table table-striped table-hover" style="width: 85%" >
                    <thead>
                        <tr>
                            <th style="width: 10%">order</th>
                            <th style="width: 20%">supplier</th>
                            <th style="width: 15%">date</th>
                            <th style="width: 10%">quantity</th>
                            <th style="width: 12%">total(Rs)</th>
                            <th style="width: 15%">created</th>
                            <th style="width: 18%">last updated</th>
                            <th style="width: 10%"></th>
                        </tr>
                    </thead>
                        <?php foreach($orders as $order): ?>
                            <tr>
                                <td> <big><?php echo e($order->id); ?></big></td>
                                <td> <?php echo e($order->supplier->name); ?></td>
                                <td> <?php echo e($order->date); ?></td>
                               
                                 <?php if(count($order->item_order)>0): ?>
                                  <?php
                                        $tot=0;
                                        $amount=0;

                                    foreach($order->item_order as $items){
                                        
                                       
                                        $tot+=$items->amount*$items->unit_price;
                                         $amount+=$items->amount;
                                        
                                       // {{$items}}
                                   }
                                   ?>
                                    
                                
                               <td> <?php echo e($amount); ?></td>
                                <td><?php echo e($tot); ?></td>
                                
                                 <?php else: ?>
                                 <td>0</td>
                                <td>0</td>
                                 <?php endif; ?>
                                <td><?php echo e($order->created_at->format('Y-m-d_H:m')); ?></td>
                                <td><?php echo e($order->updated_at->format('Y-m-d_H:m')); ?></td>
                                <td> <a href="/itemorders/<?php echo e($order->id); ?>" class="btn btn-warning btn-xs">edit</a> </td>
                            </tr>
                                
                    <?php endforeach; ?>
                    </table>
                        <?php echo e($orders->links()); ?>

                    <?php else: ?>
                    no orders<br>click add order button
                    
                    <?php endif; ?>
                </div>
            
        </div>
      
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>