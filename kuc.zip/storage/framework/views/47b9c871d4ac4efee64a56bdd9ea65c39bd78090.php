<?php $__env->startSection('content'); ?>
<div class="container ">
    <div class="row ">
        <div class="panel panel-default ">
            <div class="panel-heading">
                <big>ITEMS</big>
                <a href="/items/create" class="pull-right btn btn-primary btn-sm">add item</a>
            </div>
                <div class="panel-body">
                    <?php if(count($all_items)>0): ?>
                    <table class="table table-striped table-hover" >
                        <?php foreach($all_items as $item): ?>
                            <tr>
                                <td> <big><a href="/items/<?php echo e($item->id); ?>"><?php echo e($item->name); ?></a></big></td>
                                <td><?php echo e($item->created_at->format('Y-m-d_H:m')); ?></td>
                                <td><?php echo e($item->updated_at->format('Y-m-d_H:m')); ?></td>
                                <td> 
                                   

                                    <form action="/items/<?php echo e($item->id); ?>" class="pull-right" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <a href="/items/<?php echo e($item->id); ?>/edit" class="btn btn-warning btn-xs">edit</a>
                                        <input type="submit" name="delete" value="remove" class="btn btn-danger btn-xs">
                                        <input type="hidden" name="_method" value="DELETE">
                                    </form>
                                </td>
                            </tr>
                           
                               
                              
                            
                    <?php endforeach; ?>
                    </table>
                        <?php echo e($all_items->links()); ?>

                    <?php else: ?>
                    no items<br>click add item button
                    
                    <?php endif; ?>
                </div>
            
        </div>
      
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>