<?php $__env->startSection('content'); ?>
 
<div class="container">
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-heading"><big>CREATE ISSUE <span class="label label-primary"><big>#<?php echo e($issue->id); ?></big></span></big>
                for&nbsp&nbsp&nbsp&nbsp 
                officer :<strong class="text-info"><big><?php echo e($issue->officer->name); ?></big></strong>&nbsp&nbsp
                date of issue : <strong class="text-info"><big><?php echo e($issue->issue_date); ?></big></strong>&nbsp&nbsp
                                
                <form action="/issues/<?php echo e($issue->id); ?>" class="form-group pull-right" method="POST">
                    <?php echo e(csrf_field()); ?>

                   
                    <a href="/issues/<?php echo e($issue->id); ?>/edit" class="btn btn-warning btn-xs ">edit this issue</a>&nbsp&nbsp
                     <a href="/reports/issue/<?php echo e($issue->id); ?>" class="btn btn-danger btn-xs">print</a>
                    <input type="submit" name="delete" value="delete this issue" class="btn btn-danger btn-xs">
                    <input type="hidden" name="_method" value="DELETE">
                </form>
            
            
            </div>
            <div class="panel-body">
                
            
            <?php if(count($issue->items)>0): ?>
                <table class="table table-striped table-hover" style="width: 75%" >
                    <thead>
                        <tr>
                            <th style="width: 25%">item name</th>
                            <th style="width: 15%">amount</th>
                            <th style="width: 20%">created</th>
                            <th style="width: 20%">last updated</th>
                            <th style="width: 15%"> <a href="/issueitems/create/<?php echo e($issue->id); ?>" class="btn btn-info btn-xs"> <i class="fa fa-btn fa-plus"></i>add new item</a></th>
                        </tr>
                    </thead>
                    <?php foreach($issue->items as $issue_item): ?>
                        <tr>
                            <td><?php echo e($issue_item->name); ?></td>
                            <td><?php echo e($issue_item->pivot->amount); ?></td>
                             <td> <?php echo e($issue_item->pivot->created_at->format('Y-m-d_H:m')); ?></td>
                                   <td> <?php echo e($issue_item->pivot->updated_at->format('Y-m-d_H:m')); ?></td>
                                 
                                                           
                            <td> 
                                <form action="/issueitems/<?php echo e($issue_item->pivot->id); ?>" class="form-inline" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <a href="/issueitems/<?php echo e($issue_item->pivot->id); ?>/edit" class="btn btn-warning btn-xs">edit</a>&nbsp&nbsp
                                    <input type="submit" name="delete" value="remove" class="btn btn-danger btn-xs">
                                    <input type="hidden" name="_method" value="DELETE">
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                  
                </table>
                 
                <?php /* <?php echo e($all_items->links()); ?> */ ?>
            <?php else: ?>
                <a href="/issueitems/create/<?php echo e($issue->id); ?>" class="btn btn-info btn-xs"> <i class="fa fa-btn fa-plus"></i>add new item</a></th>
                
            <?php endif; ?>      
                   
            </div>
        
            

        </div>
    </div>
    
</div>


<?php $__env->stopSection(); ?> 



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>