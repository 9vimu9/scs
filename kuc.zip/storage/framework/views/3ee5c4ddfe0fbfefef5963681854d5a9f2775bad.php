<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-heading">
                <big>OFFICERS</big>
                <a href="/officers/create" class="pull-right btn btn-primary btn-sm">add officer</a>
            </div>
                <div class="panel-body">
                    <?php if(count($all_officers)>0): ?>
                     <table class="table table-striped table-hover"style="width: 75%" >
                     <thead>
                        <tr>
                            <th style="width: 25%">name</th>
                            <th style="width: 15%">NIC</th>
                            <th style="width: 20%">created</th>
                            <th style="width: 20%">last updated</th>
                            <th style="width: 15%"></th>
                           
                        </tr>
                        <?php foreach($all_officers as $officer): ?>
                            <tr>
                                <td> <big><a href="/officers/<?php echo e($officer->id); ?>"><?php echo e($officer->name); ?></a></td>
                                <td><?php echo e($officer->nic); ?></td>

                                <td><?php echo e($officer->created_at->format('Y-m-d_H:m')); ?></td>
                                <td><?php echo e($officer->updated_at->format('Y-m-d_H:m')); ?></td>
                                
                                   

                                    <form action="/officers/<?php echo e($officer->id); ?>" class="pull-right" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <td> <a href="/officers/<?php echo e($officer->id); ?>/edit" class="btn btn-warning btn-xs">edit</a>
                                        <input type="submit" name="delete" value="remove" class="btn btn-danger btn-xs">
                                        <input type="hidden" name="_method" value="DELETE">
                                    </form>
                                </td>
                            </tr>
                           
                               
                              
                            
                    <?php endforeach; ?>
                    </table>
                        <?php echo e($all_officers->links()); ?>

                    <?php else: ?>
                    no officers<br>click add officer button
                    
                    <?php endif; ?>
                </div>
            
        </div>
      
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>