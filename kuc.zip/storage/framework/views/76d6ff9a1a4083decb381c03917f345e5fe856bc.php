<?php $__env->startSection('head'); ?>



 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">

    <div class="row">
        <div class="panel panel-default">
            <div class="panel-heading">
            
            <?php if($reportrequest->type==1): ?>
                <big>monthly item request report <?php echo e($reportrequest->created_at->format('M,Y')); ?></big>
            <?php else: ?>
                <big>quick report <?php echo e($reportrequest->created_at->format('d-M-Y')); ?></big>
            <?php endif; ?>
              
                  
                   
             <form action="/orders/" class="form-group pull-right" method="POST">
                    <?php echo e(csrf_field()); ?>

                   
                   <input type="submit" name="delete" value="delete this order" class="btn btn-danger btn-xs">
                    <input type="hidden" name="_method" value="DELETE">
                </form>

              </div>
            </div>
            <div class="panel-body">
            <?php /* <?php if(count($items)>0): ?>
                <table id="current" class="table table-hover table-striped"  width="100%">
                    <thead>
                        <tr>
                            <th width="25%">name</th>
                            <th width="5%">now</th>
                            <th width="10%">reorder</th>
                            <th width="15%">category</th>
                            <th width="10%">code</th>
                            <th width="10%">location</th>
                           
                            <th width="8%">max</th>
                            
                            <th width="8%">min</th>
                            <th width="20%">add
                            
                                        <div class="material-switch pull-right">
                                            <input id="mainAdd" name="mainAdd" type="checkbox" />
                                            <label for="mainAdd" class="label-default"></label>
                                        </div>
                                   


                            </th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php foreach($items as $item): ?>
                            <?php if(($item->reorder-$item->current)>=0): ?>
                            
                                <tr>
                                    <td> <a href="/items/<?php echo e($item->id); ?>"><?php echo e($item->name); ?></a></td>
                                    <td><?php echo e($item->current); ?></td>
                                    <td><?php echo e($item->reorder); ?></td>
                                    <td><?php echo e($item->cat->name); ?></td>
                                
                                    <td><?php echo e($item->code); ?></td>
                                    <td><?php echo e($item->location); ?></td>
                                    
                                    <td><?php echo e($item->max); ?></td>
                                
                                    <td><?php echo e($item->min); ?></td>
                                
                                    <td>

                                        <div class="material-switch ">
                                            <input id="toreport_<?php echo e($item->id); ?>" name="toreport" class="to_report" type="checkbox" />
                                            <label for="toreport_<?php echo e($item->id); ?>" class="label-danger"></label>
                                        </div>
                                    </td>
                                </tr>
                                
                                    
                                    
                            <?php endif; ?>        
                        <?php endforeach; ?>   
              
                    </tbody>
                
                </table>
            <?php else: ?>
                no officers<br>click add officer button
                    
            <?php endif; ?> */ ?>

            </div>
            
        </div>
      
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("script"); ?>
<script> 
$(document).ready(function() {

    $("#to_this_month_button, #to_quick_button").click(function() {
        var selected_ids=[];
        $('.to_report').each(function(){
            if(this.checked){
                var item_id=$(this).attr('id').split("_")[1];
                selected_ids.push(item_id);


            }
            
        })

        $("#selected_ids").val(selected_ids);
    });




     $('#mainAdd').change(function(){
          $('.to_report').prop("checked", this.checked);
        
     });

    $('#current').DataTable( {
        "columnDefs": [{"targets": 8,"orderable": false}],
        "order": [[ 1, "asc" ]],
         "createdRow": function ( row, data, index ) {
             var val=255;
             var diffrence=data[2]-data[1];
             if(diffrence>0){
                val=265-(diffrence/data[6])*255-50;
                val=parseInt(val);
             
             }
             console.log(val);
           
            
                $('td', row).eq(1).css({'font-size':' 120%',"font-weight": "bold", "background-color": "rgb(200, "+val+",100 )"});
            
        }
    } );
});
</script>

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>