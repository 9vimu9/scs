@extends('layouts.app')



@section('content')
<div >

        <h1 class="text-center">KESBEWA URBAN COUNCIL</h1>
        <h3 class="text-center">STOCK MANAGEMENT SYSTEM</h3>
      </div>
@endsection 

