<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cat extends Model
{
     
}
